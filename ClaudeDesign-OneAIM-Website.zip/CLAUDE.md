# Project instructions

- Do not use em dashes (—) in any user-facing copy. Use commas, colons, or periods instead.
