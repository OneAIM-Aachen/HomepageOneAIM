// Organization-wide team database (blueprint — in production this is a TS/JSON collection in the Astro repo).
// Add a member: one entry here. Open a new city: one entry in `cities` — every page section scales automatically.
export const cities = [
  { id: 'aachen', name: 'Aachen', university: 'RWTH Aachen' },
  { id: 'munich', name: 'Munich', university: 'LMU & TUM' },
  { id: 'frankfurt', name: 'Frankfurt', university: 'Goethe University' },
];

const P = 'website/public/images/team/';
export const members = [
  { name: 'Constantin Lemler', position: 'President', city: 'aachen', lead: true, linkedin: '#', photo: P + 'constantin-lemler.png' },
  { name: 'Aliya Zwiens', position: 'Team Lead Events', city: 'aachen', lead: true, linkedin: '#', photo: P + 'aliya-zwiens.png' },
  { name: 'Lucas Gildehaus', position: 'Team Lead Partnerships', city: 'aachen', lead: true, linkedin: null, photo: P + 'lucas-gildehaus.png' },
  { name: 'Sophie Bauer', position: 'Events', city: 'aachen', lead: false, linkedin: '#', photo: P + 'sophie-bauer.svg' },
  { name: 'Lena Hartmann', position: 'Marketing', city: 'aachen', lead: false, linkedin: null, photo: P + 'lena-hartmann.svg' },
  { name: 'Jonathan Rempel', position: 'Partnerships', city: 'aachen', lead: false, linkedin: '#', photo: P + 'jonathan-rempel.png' },
  { name: 'Eric Hoelpes', position: 'IT & Website', city: 'aachen', lead: false, linkedin: '#', photo: P + 'eric-hoelpes.png' },
  { name: 'Anna Vogel', position: 'Events', city: 'aachen', lead: false, linkedin: null, photo: P + 'anna-vogel.svg' },
  { name: 'David Forster', position: 'President', city: 'munich', lead: true, linkedin: '#', photo: P + 'david-forster.png' },
  { name: 'Sebastian Ha', position: 'Team Lead Aim Code', city: 'munich', lead: true, linkedin: '#', photo: P + 'sebastian-ha.png' },
  { name: 'Huang Lin', position: 'Team Lead Finance', city: 'munich', lead: true, linkedin: '#', photo: P + 'huang-lin.png' },
  { name: 'Alex Mladenov', position: 'Aim Code', city: 'munich', lead: false, linkedin: '#', photo: P + 'alex-mladenov.jpeg' },
  { name: 'Sven Mattus', position: 'Partnerships', city: 'munich', lead: false, linkedin: null, photo: P + 'sven-mattus.png' },
  { name: 'Yujin Song', position: 'Marketing', city: 'munich', lead: false, linkedin: '#', photo: P + 'Yujin_Song.png' },
  { name: 'Tobias Klein', position: 'Events', city: 'munich', lead: false, linkedin: '#', photo: P + 'tobias-klein.svg' },
  { name: 'Mara Lindner', position: 'Finance', city: 'munich', lead: false, linkedin: null, photo: P + 'mara-lindner.svg' },
  { name: 'Jonas Weber', position: 'Aim Code', city: 'munich', lead: false, linkedin: '#', photo: P + 'jonas-weber.svg' },
  { name: 'Felix Schmidt', position: 'IT & Website', city: 'munich', lead: false, linkedin: '#', photo: P + 'felix-schmidt.svg' },
  { name: '[Name]', position: 'President', city: 'frankfurt', lead: true, linkedin: '#', photo: P + 'anna-vogel.svg' },
  { name: '[Name]', position: 'Team Lead Events', city: 'frankfurt', lead: true, linkedin: null, photo: P + 'tobias-klein.svg' },
  { name: '[Name]', position: 'Events', city: 'frankfurt', lead: false, linkedin: '#', photo: P + 'mara-lindner.svg' },
  { name: '[Name]', position: 'Marketing', city: 'frankfurt', lead: false, linkedin: null, photo: P + 'jonas-weber.svg' },
];
