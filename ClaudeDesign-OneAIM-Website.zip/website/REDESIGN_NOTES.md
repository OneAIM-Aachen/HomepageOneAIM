# Redesign changes (vs TestWebsite-branchLucas)

Design language: white page, ink headlines with AIM-Blue accents, purple overlines,
pill buttons/inputs, hairline cards with soft blue shadows, brand ease-out motion.
Pixel reference: "Site Preview v2.html" in the design project.

Changed files:
- src/styles/tokens.css — white page bg, ink headings, hairline border, soft shadows (+--shadow-lift), smaller display/body-lg scale, brand easing, header 72px, hero gradient removed
- src/styles/global.css — headings weight 800, letter-spacing -0.02em
- src/components/ui/Button.astro — pill radius, primary glow + #0041ba hover, secondary now ghost (border) instead of gradient
- src/components/navigation/Header.astro — ink links, blue hover/active, no underlines
- src/components/cards/IconCard.astro — 20px radius, hairline border, hover lift
- src/components/sections/MissionSection.astro — white section, Light-Blue rounded panel around the grid
- src/components/sections/PartnersSection.astro — purple overline, tighter top padding
- src/components/navigation/Footer.astro — pill inputs and submit
- src/pages/index.astro — Hero replaced by MapHero
- src/components/sections/MapHero.astro — NEW: DACH map hero (dot-filled Germany, grey outlines, pinging pins → /aachen /frankfurt /muenchen)
- src/pages/frankfurt.astro — NEW: stub route for the Frankfurt pin

Not yet restyled (inherit tokens, may need a pass): city pages/Hero.astro (now flat white), Carousel, Timeline, FAQ, contact/legal pages.
