# OneAIM Design System

> **OneAIM** — *Advancing Technology in Healthcare.*
> A student-led MedTech initiative bridging medicine and technology through an interdisciplinary network of excursions, workshops and build events.

This repository is the single source of truth for the OneAIM brand: color, typography, iconography, reusable UI components, a marketing-website UI kit, and presentation slide templates. Link `styles.css` to inherit every token.

---

## 1. Company & product context

OneAIM is a non-profit, student-run organisation (a *Hochschulgruppe* / collective incubator) operating chapters in **Aachen** (RWTH) and **Munich** (its sibling initiative, originally founded at LMU/TUM). Its mission is to close the gap between medical practice and modern technology — and to address pressing challenges in the healthcare system: staff shortages, rising demand from demographic change, and slow digitalisation/bureaucracy.

It does this by **building an interdisciplinary network** — medical students alongside informatics, electrical-engineering, physics, maths and business students — through excursions, expert talks, hands-on workshops and a closing **Make-A-Thon** hackathon.

### Programs (the "Aim" family)
- **Aim Connect** — flagship semester program: a kickoff weekend, ~8 weekly workshops, and a closing hackathon. (SS2026 itinerary included lab visits, robotics-in-medicine talks, an OP visit at UKA, and a Make-A-Thon.)
- **Aim Code** — programming courses for students of all disciplines, focused on AI and medical data analysis.
- **Aim Innovate**, **Aim Science**, **Aim Educate** — further programs, expandable with additional funding.

### Traction (from the Munich sibling initiative)
- Orga team of 40+ members
- 500+ students networked across programs
- 30+ successful partnerships (e.g. Carl Zeiss AG, the German Federal Ministry of Health)

### Partners & supporters
RWTH Aachen, LMU, TUM, university hospitals (UKA), and MedTech corporate partners. Schirmherr (patron): Univ.-Prof. Dr. med. Dipl.-Phys. Daniel Truhn, M.Sc.

### Surfaces
- **Marketing website** ("Unsere Website") — primary public surface; programs, vision, team, partners, CTA to apply/join.
- **Presentation decks** — partner & recruiting pitches (German), 16:9.
- **Social posts** — Instagram/LinkedIn, designed 4:5 (with 1:1 safe area) in Canva.

### Source material
- `uploads/brand_style_guide.pdf` — *OneAIM Brand Style Guide & Templates* (28.02.2025): typography, color palette, logo, photography & social templates.
- `uploads/oneaim_presentation.pptx` — *OneAIM Vorstellung — Partner / Collective Incubator* (German partner deck). Logos, team photos and Office stock icons were extracted from it into `assets/`.
- Logos live on the org's Notion (per the guide); the versions here were extracted from the deck.

---

## 2. Content fundamentals — how OneAIM writes

**Voice:** warm, inspiring, can-do, and credible. It is a student initiative, so the tone is approachable and energetic — never corporate-stiff — but it leans on real medical/technical substance to earn trust.

**Language:** primary public/partner communication is **German**; the tagline and program names are **English** ("Advancing Technology in Healthcare", "Aim Connect", "Make-A-Thon"). English-language material mirrors the same warmth.

**Person:** collective **"we / unser" (our)** for the organisation — "Unsere Vision", "Unser Programmangebot", "Unser Team". Direct **"you"** address when calling the reader to act.

**Casing:** Headlines are sentence-case or title-ish, not SHOUTY. The wordmark is **OneAIM** (camel with capital AIM). Program names capitalise the verb: *Aim Connect*, *Aim Code*.

**CTAs — "friendly and soft approach"** (explicit guide rule): invite, don't command. Always (1) name the audience ("medical students, medical professionals, all students…"), (2) state the topic/project, (3) give a teaser, (4) the key facts, (5) a soft CTA. e.g. *"Du studierst Medizin oder Informatik? Werde Teil von Aim Connect."*

**Emoji:** not part of the brand system — avoid in product/marketing UI. (Social captions may use them sparingly; the design system does not.)

**Examples (from real material):**
- "Aktuelle Herausforderungen in unserem Gesundheitssystem" (Current challenges in our healthcare system)
- "Hier möchten wir ansetzen und unseren Beitrag zur Lösung dieser Probleme leisten!" (This is where we want to start and contribute to solving these problems!)
- "Aufbau eines interdisziplinären Netzwerks durch unsere Exkursionen und Workshops"
- Tagline: "Advancing Technology in Healthcare"

**Vibe:** purpose-driven, future-of-medicine optimism, student community, hands-on ("Make-A-Thon", "Hands-on Workshop").

---

## 3. Visual foundations

**Overall feel:** clean, bright, blue-forward and modern — clinical trust meets tech optimism. Lots of white space; light-blue washes for warmth; purple/pink reserved as the "innovation/highlight" spark.

### Color
- **AIM Blue `#0052E9`** is the hero — trust + the medical industry. Used for primary actions, the logo, headlines on white.
- **Light Blue `#C9D8FF`** is the workhorse background (presentations, social, upcoming-project surfaces).
- **Dark Blue `#232ACF`** replaces black for text/headlines *on light-blue* surfaces.
- **Pink `#D400FF`** + **Purple `#8D2DF1`** are secondary accents signalling **creativity & innovation**; used together they mark **highlight events** (summits, international events) and graduation moments. Use as a *splash*, not a flood.
- **Black `#000000`** backgrounds (white text) denote **completed/past projects** ("how it went") in social.
- Each brand color ships with 20/40/60/80% tints (see `tokens/colors.css` scales).

### Typography
- **Raleway** for everything — display, headline, subtitle and body. Geometric, friendly, contemporary.
- Scale anchors from the guide: Display **110px**, Headline **35px**, Subtitle **20px**, body paragraph for comfortable multi-line reading.
- Headlines are bold/extrabold with slightly tight tracking; body is regular with relaxed line-height; overlines are uppercase, tracked, often in the purple accent.

### Backgrounds & texture
Predominantly **flat color** — white, light-blue washes, or black for "done" content. **Brand gradient** (blue→purple) appears on the logo dot and may accent hero elements or highlight badges, used sparingly. No heavy textures, no skeuomorphism. Imagery is **clean and naturalistic** (guide: *clarity* — single-subject, clutter-free; *naturalism* — no stagey shots, don't crop heads).

### Imagery vibe
Bright, natural daylight, real people (team & event photos), neutral/cool-warm balance, not over-filtered. Portraits are simple head-and-shoulders on plain backgrounds.

### Shape & corners
Generously rounded — radii from 10–28px on cards and controls, pill shapes for tags/buttons. The logo mark itself is built from soft, rounded strokes.

### Cards
White surface, subtle 1px `--border-subtle` and/or soft blue-tinted shadow (`--shadow-sm`/`--shadow-md`), radius `--radius-lg` (20px). Tinted variant uses Light-Blue fill with Dark-Blue text. No colored-left-border cards.

### Borders & shadows
Hairline neutral borders (`--gray-200`). Shadows are **soft and cool**, tinted with dark-blue/blue alpha — never hard black drop shadows. Elevation ladder: xs → sm → md → lg, plus brand/accent glows for primary CTAs.

### Motion
Calm and confident: `ease-out` (`cubic-bezier(0.22,1,0.36,1)`), 120–360ms. Fades and gentle rises; **no bouncy/springy** overshoot. Respect `prefers-reduced-motion`.

### Hover / press states
- **Hover:** primary buttons darken (AIM Blue → `--blue-600`); cards lift via larger shadow + ~2px rise; links underline.
- **Press/active:** darken further (`--blue-700`) and settle (translateY 0 / slight scale 0.99). No dramatic shrink.
- **Focus:** 3px soft blue focus ring (`--focus-ring`).

### Transparency & blur
Used lightly — translucent light-blue overlays on imagery, optional backdrop blur on sticky headers. Not a core motif.

### Layout
Centered max-width container (`--container-max` 1200px), generous section padding (`--section-y`), 4px spacing grid. Social designed 4:5 with 1:1 safe area (guide).

---

## 4. Iconography

OneAIM's deck uses **Microsoft Office stock line/solid icons** — a clean, single-weight monoline-to-solid black style (e.g. Bullseye, ArtificialIntelligence/brain, LightBulb-and-Gear, Connections, Users, Handshake, Cheers, DoctorFemale, Monitor, UpwardTrend). These were extracted as SVGs into **`assets/icons/`** and made tintable (`fill="currentColor"`), so they take on `color` — use AIM Blue, Dark Blue, or the purple accent.

- **Format:** SVG (96×96 viewBox), single color. PNG copies also exist in the source.
- **Style:** geometric, medium weight, rounded terminals; semantic to MedTech (brain, doctor, target/aim, network).
- **Sizing:** render at 20–48px in UI; larger as feature/program glyphs.
- **Emoji:** not used as icons. **Unicode** is not relied on for iconography.
- **Substitution:** for icons not in this set, use **[Lucide](https://lucide.dev)** (consistent monoline, rounded) as the closest CDN match — *flag any substitution*. Avoid mixing multiple icon families on one surface.

Brand glyph: the **"Ai" mark** (an A fused with a dotted *i*; the dot is a purple ring) — see `assets/logos/`. Don't recolor or redraw it; use the provided files.

---

## 5. Index / manifest

**Root**
- `styles.css` — global entry (link this). `@import`s only.
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `effects.css`, `fonts.css`, `base.css`.
- `assets/` — `logos/` (logo, logo+tagline), `icons/` (10 brand SVG icons), `team/` (member portraits).
- `SKILL.md` — Agent-Skills-compatible entry.
- `readme.md` — this file.

**Components** (`components/`) — see each `*.prompt.md`:
- `core/` — `Button`, `Tag`, `IconBadge`, `Avatar`
- `data-display/` — `Card`, `ProgramCard`, `StatCard`, `TeamCard`
- `forms/` — `Input`
- `navigation/` — `Navbar`

**UI kits** (`ui_kits/`)
- `website/` — OneAIM marketing website (hero, programs, vision, team, partners, CTA).

**Slides** (`slides/`) — 16:9 deck templates (title, agenda/vision, program, team, big-quote/CTA).

**Design System tab** — every `@dsCard`-tagged HTML renders there, grouped: *Brand, Colors, Type, Spacing, Components, Website, Slides*.

---

## ⚠️ Substitution notes (please review)
- **Raleway** is loaded from **Google Fonts** (the brand typeface; no licensed binaries were provided). If you have the font files, drop them in and swap `tokens/fonts.css` to local `@font-face`.
- **Icons** are the Office stock SVGs pulled from the deck; **Lucide** is recommended for any missing glyphs (flag when used).
- Logos were extracted from the PPTX, not the original Notion source — request vector/master logo files if available.
