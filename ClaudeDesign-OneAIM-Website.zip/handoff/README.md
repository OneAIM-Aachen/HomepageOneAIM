# OneAIM Map-Hero — Handoff

Drop-in for `TestWebsite-branchLucas` (Astro 6). Design: hero 1d from the
mockups — fine dot-fill Germany, light-grey country outlines, pinging
clickable pins on Aachen, Frankfurt, Munich.

## Files

- `src/components/sections/MapHero.astro` → copy to the same path in your repo.
- `src/pages/frankfurt.astro` → stub page for the Frankfurt pin (route `/frankfurt`).

## Wiring (src/pages/index.astro)

1. Add the import:
   ```astro
   import MapHero from "../components/sections/MapHero.astro";
   ```
2. Replace the whole `<Hero …>…</Hero>` block with:
   ```astro
   <MapHero />
   ```
   The München/Aachen CTA buttons are inside MapHero, so the
   `Hero`/`Button` imports and the `.hero-city-btn` `<style>` block at the
   bottom of index.astro can be removed.

## Notes

- Map libraries (d3 + topojson-client) load from CDN with pinned,
  integrity-checked script tags — no npm install needed. Geometry comes from
  the public-domain world-atlas TopoJSON (fetched at runtime, ~800 KB,
  cached by the browser). If you prefer bundling, `npm i d3 topojson-client`
  and move the inline script into a module.
- The map draws once at load; on window resize it keeps its viewBox
  (scales fluidly, no redraw needed).
- Pins link to `/aachen`, `/frankfurt`, `/muenchen`. Frankfurt is a stub —
  extend `src/data/cityData.ts` (`CitySlug`) when the chapter goes live.

## Design-language review (your open question)

Your `tokens.css` already matches the OneAIM brand guide well (colors,
Raleway, spacing). Gaps I'd fix for consistency, in priority order:

1. **Button shape** — guide uses pill buttons (`--radius-pill`), your
   `Button.astro` uses `--radius-sm` (8px). One-line change in Button.astro.
2. **Hero-button opacity hack** — `.hero-city-btn { opacity: 0.82 }` washes
   out the brand blue; remove it (gone anyway if you adopt MapHero).
3. **Easing** — tokens use `ease`; guide motion is
   `cubic-bezier(0.22, 1, 0.36, 1)` (ease-out, no bounce). Swap in
   `--transition-fast/base`.
4. **Aurora hero gradient** — the salmon/pink `rgba(235,100,105,…)` blobs in
   `--gradient-hero` are off-palette (pink is #D400FF, used as a splash, not
   a wash). MapHero replaces the homepage use; city-page heroes could move
   to a flat Light-Blue (`--color-bg-subtle`) with Dark-Blue text.
5. **Card radius** — guide cards are 20px (`--radius-lg`); `.card-base`
   uses `--radius-md` (14px). Cosmetic, pick one and apply everywhere.

Happy to do a file-by-file restyle pass (Header, cards, sections) next —
say the word.
