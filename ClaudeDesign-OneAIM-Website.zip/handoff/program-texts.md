# Program subpage texts (verbatim from user, 2026-08-17)

## AIM Connect
AIM Connect is an exclusive add-on study program designed for students passionate about the intersection of medicine, entrepreneurship, and technology. Throughout the semester, participants gain in-depth insights into the MedTech field by engaging with a diverse stakeholders, including hospitals, research institutions, startups, and established companies. This immersive experience is complemented by peer-to-peer learning, where participants share knowledge and insights from their varied academic backgrounds.

## AIM Code
Within AIM Code, we offer a variety of specialized coding courses designed for students and medical professionals, addressing the unique challenges and opportunities at the intersection of medicine and technology. These include hands-on introductory workshops focused on learning Python, as well as advanced sessions exploring applications of artificial intelligence in healthcare. All our courses are free of charge, ensuring they remain accessible to anyone eager to develop their skills and embrace innovation in the medical field.

## AIM Innovate
AIM Innovate is an exclusive add-on study program designed for students eager to bridge the gap between great ideas and real-world impact in healthcare. The program empowers participants to navigate the complex landscape of medical innovation, from understanding political frameworks and regulatory challenges to developing a concrete strategy for turning an idea into a startup. Throughout the semester, students gain hands-on insights into how healthcare innovation takes shape, working closely with entrepreneurs, policymakers, investors, and industry experts. This journey is complemented by peer-to-peer collaboration, where participants exchange perspectives from medicine, business, and technology, while building the skill set and mindset needed to transform innovation into action.

## AIM Educate
Periodically, AIM organizes open lectures for all students interested in Medical AI. These events are held in a relaxed and informal setting, designed to foster open discussions and encourage participants to ask questions freely. Our lectures provide a platform to explore current trends, research, and innovations in Medical AI, promoting an engaging learning experience for everyone involved.

## AIM Science
OneAIM members are passionate about advancing AI research in healthcare. We actively engage in innovative projects, such as evaluating whether AI chatbots can pass the second medical state examination or exploring the capabilities of image generators in creating realistic images of patients with specific diseases.
