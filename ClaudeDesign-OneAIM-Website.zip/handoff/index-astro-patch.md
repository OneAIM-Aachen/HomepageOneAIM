# Homepage patch — "What is OneAIM" (design 2A)

1. Add `src/components/sections/WhatIsSection.astro` (file in this folder).

2. In `src/pages/index.astro`:

   - Add import:
     ```astro
     import WhatIsSection from "../components/sections/WhatIsSection.astro";
     ```

   - Replace the entire `<ContentSection heading="Germany's First Student-Led" …>…</ContentSection>` block (section ③) with:
     ```astro
     <!-- ③ Introduction – What is OneAIM -->
     <WhatIsSection />
     ```

   - Remove the now-unused `import ContentSection …` line **only if** no other page still uses ContentSection (about.astro references it in a TODO comment — keep the component file itself).

Notes:
- Background image defaults to `/images/events/aachenKickoff2026.jpg`; override via `<WhatIsSection image="/images/events/other.jpg" imageAlt="…" />`.
- No stats in this section (they already live on the landing hero).
