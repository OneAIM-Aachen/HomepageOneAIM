# Handoff: OneAIM Design Language Refresh (Landing Page + Site-wide)

## Overview
Restyle of the OneAIM Astro website (`TestWebsite-branchLucas`, Astro 6, plain scoped CSS, no framework) to a cleaner landing-page design language: white page, ink headlines with AIM-Blue accents, purple overlines, pill buttons, hairline cards with soft blue shadows, and a new homepage hero with a minimalist DACH map (dot-filled Germany, grey country outlines, pinging clickable pins on Aachen, Frankfurt, Munich).

## About the Design Files
The bundled files are **design references created in HTML** — they show the intended look and behavior, they are not production code to copy verbatim (except the two `.astro` files, which are drop-in ready). The task is to **apply this design language across the existing Astro codebase** using its established patterns: design values live in `src/styles/tokens.css`, components are `.astro` files with scoped `<style>` blocks. Keep all existing content, copy, routes and nav structure — only the visual language changes.

## Fidelity
**High-fidelity.** `Site Preview v2.html` is the pixel reference for the homepage. Match colors, type, radii, shadows and spacing exactly; recreate other pages (city pages, news, publications, contact) in the same language by analogy.

## Design Tokens
Update `src/styles/tokens.css` to these values (keep existing variable names where they exist):

Colors
- AIM Blue (primary): `#0052E9`; hover-darken: `#0041ba`; Dark Blue: `#232ACF`
- Light Blue (accent panels only, never full-page bg): `#C9D8FF`
- Purple accent (overlines, map pins, footer submit): `#8D2DF1`; hover `#7120c8`
- Pink `#D400FF` only inside the icon gradient: `linear-gradient(135deg,#D400FF 0%,#8D2DF1 100%)`
- Ink headline: `#111`; body text: `#3d4356`; muted: `#6b7186`; hairline border: `#e4e7ee`
- Page background: `#ffffff` (replaces `#EEF3FF`)

Typography (Raleway everywhere)
- Display (hero h1): `clamp(2.6rem, 2rem + 3vw, 3.6rem)`, weight 800, letter-spacing -0.02em, line-height 1.12
- h2: `clamp(1.5rem, 1.25rem + 1vw, 2.1rem)`, weight 800, ink `#111` (Dark Blue `#232ACF` on Light-Blue panels)
- h3: 1.25rem, weight 700
- Body: 1.0625rem / 1.6; small: 15px; captions/labels: 13px
- Overline: 13px, weight 700, uppercase, letter-spacing 0.14em, color `#8D2DF1`
- Heading accents: wrap key phrase in a span colored `#0052E9`

Shape & elevation
- Buttons/inputs: pill (`border-radius: 999px`)
- Cards: 20px radius, `1px solid #e4e7ee`, shadow `0 2px 10px rgba(35,42,207,.05)`
- Feature panels: 28px radius, shadow `0 18px 44px rgba(35,42,207,.10)`
- Primary button glow: `0 6px 18px rgba(0,82,233,.28)`
- Never hard black shadows.

Motion
- Easing: `cubic-bezier(0.22, 1, 0.36, 1)` (replace all `ease` transitions), 150–220ms
- Hover: buttons `translateY(-2px)` + darken; cards `translateY(-2px)` + shadow grows to the panel shadow
- Respect `prefers-reduced-motion` (already handled globally in `global.css`).

## Components
- **Button.astro** — pill radius; primary: AIM Blue bg, white text, blue glow shadow, hover `#0041ba`; secondary: ghost — transparent bg, `1.5px solid rgba(0,82,233,.35)` border, blue text, hover `rgba(0,82,233,.06)` bg. Remove the gradient secondary and the `.hero-city-btn` opacity hack.
- **Header.astro** — white 92% + blur, `1px solid rgba(0,0,0,.06)` bottom border, height 72px; links 15px/600 ink `#111`, hover blue, active page blue (no underline).
- **IconCard.astro** — white, 20px radius, hairline border + soft shadow, hover lift; keep the 48px pill icon badge with the pink→purple gradient.
- **Section headers** — purple uppercase overline above each h2 (e.g. "Our partners", "Introduction").
- **MissionSection** — white section; the 2×2 card grid sits inside a Light-Blue rounded panel (28px radius, 56px/48px padding, panel shadow); heading Dark Blue.
- **Footer** — keep blue CTA band + black base; inputs and submit become pills; submit is purple `#8D2DF1`, hover `#7120c8`.
- **MapHero.astro** (new, drop-in included) — replaces the aurora-gradient hero on the homepage. Left: overline, display headline, lead, München (primary) / Aachen (ghost) buttons, stats row (3 / 500+ / 30+). Right: 560px DACH map — all country borders as `#dfe2e9` 1.1px outlines, Germany filled with a 6px grid of 1.32px dots `#c3d3fb`, purple pins with staggered ping rings (2.2s, brand easing), hover grows pin + reveals "View chapter →", pins link to `/aachen`, `/frankfurt`, `/muenchen`. Geometry: world-atlas TopoJSON via d3-geo (pinned CDN tags inside the component; no npm deps). Never hand-draw the geography.

## Interactions & Behavior
- Map pins: `<a>` elements inside the SVG; ping animation disabled under reduced motion.
- `/frankfurt` stub page included; extend `src/data/cityData.ts` when the chapter is real.
- All other behavior (mobile menu, carousel, forms) unchanged.

## State Management
None new. The map draws once on load from fetched TopoJSON; no state libraries.

## Assets
- Logo: existing `public/logo.png`.
- Map data: `https://cdn.jsdelivr.net/npm/world-atlas@2.0.2/countries-50m.json` (public domain), d3 7.9.0 + topojson-client 3.1.0 via pinned CDN script tags (integrity hashes included in MapHero.astro).
- Partner logos: existing placeholders in `public/images/partners/`.

## Files
- `Site Preview v2.html` — pixel reference: full homepage in the target design language (partner logos are placeholder tiles).
- `src/components/sections/MapHero.astro` — production-ready hero component.
- `src/pages/frankfurt.astro` — stub route for the Frankfurt pin.
- Wire-up: in `src/pages/index.astro`, import MapHero and replace the `<Hero …>…</Hero>` block with `<MapHero />`; remove the `.hero-city-btn` style block.

## Suggested Claude Code prompt
"Read design_handoff_oneaim_design_language/README.md and Site Preview v2.html, then apply this design language across the whole site: update tokens.css and global.css, restyle Button/Header/IconCard/sections/Footer to match, drop in MapHero.astro and frankfurt.astro, and wire MapHero into index.astro. Keep all content, copy and routes unchanged."
